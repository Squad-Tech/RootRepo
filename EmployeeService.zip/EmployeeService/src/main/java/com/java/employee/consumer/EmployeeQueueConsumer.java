package com.java.employee.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.java.employee.dto.PfResponseDto;
import com.java.employee.service.EmployeeService;

@Component
public class EmployeeQueueConsumer {

	private static final Logger log = LoggerFactory.getLogger(EmployeeQueueConsumer.class);

	@Autowired
	EmployeeService employeeService;
	
	@JmsListener(destination = "employee.queue",containerFactory = "jmsFactory")
	public void queueConsumer(String xml) {
		
		log.info("xml:"+xml);
		PfResponseDto pfDto = null;
		XmlMapper mapper = new XmlMapper();
		
			try {
				
				if(xml != null && xml.toLowerCase().contains("<providentfund>"))
					pfDto =	mapper.readValue(xml,PfResponseDto.class);
					/*
					 * else mapper.readValue(xml, );
					 */
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			employeeService.saveDetails(pfDto);
		
	}
}
