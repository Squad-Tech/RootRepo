package com.java.employee.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class PfResponseDto implements QueueResponseDto,Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long pfNumber;
    private BigDecimal pfAmount;
    private String pfTrustName;
    private Long uanNumber;
    private Long mobileNumber;
    private boolean providentFund;
	
    
    
	public Long getPfNumber() {
		return pfNumber;
	}



	public void setPfNumber(Long pfNumber) {
		this.pfNumber = pfNumber;
	}



	public BigDecimal getPfAmount() {
		return pfAmount;
	}



	public void setPfAmount(BigDecimal pfAmount) {
		this.pfAmount = pfAmount;
	}



	public String getPfTrustName() {
		return pfTrustName;
	}



	public void setPfTrustName(String pfTrustName) {
		this.pfTrustName = pfTrustName;
	}



	public Long getUanNumber() {
		return uanNumber;
	}



	public void setUanNumber(Long uanNumber) {
		this.uanNumber = uanNumber;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public boolean isProvidentFund() {
		return providentFund;
	}



	public void setProvidentFund(boolean providentFund) {
		this.providentFund = providentFund;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	@Override
	public String toString() {
		return "PfResponseDto [pfNumber=" + pfNumber + ", pfAmount=" + pfAmount + ", pfTrustName=" + pfTrustName
				+ ", uanNumber=" + uanNumber + ", mobileNumber=" + mobileNumber + ", providentFund=" + providentFund
				+ "]";
	}
    
}
