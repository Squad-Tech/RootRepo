package com.java.employee.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.java.employee.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

	//@Query(nativeQuery = true,value = "SELECT * FROM emp_service.t_employee_details where mobile_number=?")
	public Optional<Employee> findByMobileNo(long mobileNumber);
}
