package com.java.employee.service.impl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.employee.dto.PfResponseDto;
import com.java.employee.dto.QueueResponseDto;
import com.java.employee.entity.Employee;
import com.java.employee.exceptions.EmployeeNotFoundException;
import com.java.employee.repository.EmployeeRepository;
import com.java.employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	
	private static final Logger log = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	
	@Autowired
	private EmployeeRepository repo;

	@Override
	public Employee getEmployeeDetails(Long id) {
		Optional<Employee> findById = repo.findById(id);
		if(findById.isPresent()) {
			throw new EmployeeNotFoundException("Employee not found");
		}
		return repo.findById(id).get();
	}

	@Override
	public void saveDetails(QueueResponseDto responseDto) {
		PfResponseDto pfDto= (PfResponseDto) responseDto; 
		log.info("{}",pfDto);
		Optional<Employee> employeeByMobile= repo.findByMobileNo(pfDto.getMobileNumber());
		if(!employeeByMobile.isPresent()) {
			throw new EmployeeNotFoundException("Employee not found");
		}
		Employee emp = employeeByMobile.get();
		log.info("{}",emp);
		
		emp.setPfNumber(pfDto.getPfNumber());
		emp.setPfAmount(pfDto.getPfAmount());
		emp.setPfTrustName(pfDto.getPfTrustName());
		emp.setUanNumber(pfDto.getUanNumber());
		repo.save(emp);	
	}
	
	
	
	
}
