package com.java.employee.dto;

public interface QueueResponseDto {

}
