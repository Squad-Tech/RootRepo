package com.java.employee.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "T_Employee_Details")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="employee_Id")
	private Long employeeId;
	@Column(name="First_name")
	private String firstName;
	@Column(name="Last_name")
	private String lastName;
	@Column(name="Address")
	private String address;
	@Column(name="Mobile_Number")
	private Long mobileNo;
	@Column(name="Email_Id")
	private String emailId;
	@Column(name="Date_Of_Birth")
	private Date dateOfBirth;
	@Column(name="Account_Number")
	private Long accountNumber;
	@Column(name="Available_Balance")
	private double availableBalance;
	@Column(name="Bank_Name")
	private String bankName;
	@Column(name="IFSC_Code")
	private String ifscCode;
	@Column(name="Pan_Number")
	private int panNumber=0;
	@Column(name="Pf_Number")
	private Long pfNumber;
	@Column(name="Pf_Amount")
	private BigDecimal pfAmount;
	@Column(name="Pf_Trust_Name")
	private String pfTrustName;
	@Column(name="Uan_Number")
	private Long uanNumber;
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", mobileNo=" + mobileNo + ", emailId=" + emailId + ", dateOfBirth="
				+ dateOfBirth + ", accountNumber=" + accountNumber + ", availableBalance=" + availableBalance
				+ ", bankName=" + bankName + ", ifscCode=" + ifscCode + ", panNumber=" + panNumber + ", pfNumber="
				+ pfNumber + ", pfAmount=" + pfAmount + ", pfTrustName=" + pfTrustName + ", uanNumber=" + uanNumber
				+ "]";
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(double availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public int getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(int panNumber) {
		this.panNumber = panNumber;
	}
	public Long getPfNumber() {
		return pfNumber;
	}
	public void setPfNumber(Long pfNumber) {
		this.pfNumber = pfNumber;
	}
	public BigDecimal getPfAmount() {
		return pfAmount;
	}
	public void setPfAmount(BigDecimal pfAmount) {
		this.pfAmount = pfAmount;
	}
	public String getPfTrustName() {
		return pfTrustName;
	}
	public void setPfTrustName(String pfTrustName) {
		this.pfTrustName = pfTrustName;
	}
	public Long getUanNumber() {
		return uanNumber;
	}
	public void setUanNumber(Long uanNumber) {
		this.uanNumber = uanNumber;
	}
	
	
	
	
	

}
