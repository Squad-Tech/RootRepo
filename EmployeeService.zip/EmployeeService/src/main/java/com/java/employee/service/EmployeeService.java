package com.java.employee.service;

import com.java.employee.dto.QueueResponseDto;
import com.java.employee.entity.Employee;

public interface EmployeeService {
	
public Employee getEmployeeDetails(Long id);

public void saveDetails(QueueResponseDto responseDto);
}
