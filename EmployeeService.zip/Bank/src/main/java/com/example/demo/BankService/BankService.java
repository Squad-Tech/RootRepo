package com.example.demo.BankService;

import Bankdto.BankDtoRequest;

public interface BankService {
	
	public String Bank(BankDtoRequest dtorequest);
}
