package com.example.demo.Bankdto;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BankDtoRequest implements Serializable {
	private int baccountNo;
	private double accountBal;
	private String Bankname;
	private String Ifsccode;
	private Long mobileNo;
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getBaccountNo() {
		return baccountNo;
	}
	public void setBaccountNo(int baccountNo) {
		this.baccountNo = baccountNo;
	}
	public double getAccountBal() {
		return accountBal;
	}
	public void setAccountBal(double accountBal) {
		this.accountBal = accountBal;
	}
	public String getBankname() {
		return Bankname;
	}
	public void setBankname(String bankname) {
		Bankname = bankname;
	}
	public String getIfsccode() {
		return Ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		Ifsccode = ifsccode;
	}
	public String getPanNumber() {
		return PanNumber;
	}
	public void setPanNumber(String panNumber) {
		PanNumber = panNumber;
	}
	private String PanNumber;
	@Override
	public String toString() {
		return "BankDtoRequest [baccountNo=" + baccountNo + ", accountBal=" + accountBal + ", Bankname=" + Bankname
				+ ", Ifsccode=" + Ifsccode + ", PanNumber=" + PanNumber + "]";
	}
	
	
	public static void main(String[] args) {
		ObjectMapper mapper = new ObjectMapper();
		String json = "{ \"color\" : \"Black\", \"type\" : \"BMW\" }";
		try {
			Map<String,String> mp=  mapper.readValue(json, new TypeReference<Map<String, String>>(){});
			System.out.println(mp.get("color"));
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
