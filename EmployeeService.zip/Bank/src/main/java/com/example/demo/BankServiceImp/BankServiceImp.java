package com.example.demo.BankServiceImp;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.BankService.BankService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


@Service
public class BankServiceImp implements BankService{
	@Autowired
	Queue queue;
	@Autowired
	JmsTemplate jmstemplate;

	public String Bank(BankDtoRequest dtorequest) {
		String respo=null,xml=null;
		XmlMapper mapper =new XmlMapper();
		try {
			xml= mapper.writeValueAsString(dtorequest);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jmstemplate.convertAndSend(queue,xml);
		respo="Service in process";
				
		return respo;
	}

	

}
