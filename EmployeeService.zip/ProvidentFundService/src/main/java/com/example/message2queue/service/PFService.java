package com.example.message2queue.service;

import com.example.message2queue.dto.PFRequestDto;

public interface PFService {
	public String pfDetails(PFRequestDto pfrequest);

}
