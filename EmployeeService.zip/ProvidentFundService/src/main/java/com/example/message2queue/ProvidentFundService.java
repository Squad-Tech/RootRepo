package com.example.message2queue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProvidentFundService {

	public static void main(String[] args) {
		SpringApplication.run(ProvidentFundService.class, args);
	}

}
