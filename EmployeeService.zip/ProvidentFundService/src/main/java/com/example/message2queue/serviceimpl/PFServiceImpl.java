package com.example.message2queue.serviceimpl;

import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.example.message2queue.dto.PFRequestDto;
import com.example.message2queue.service.PFService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
@Service
public class PFServiceImpl implements PFService{
	@Autowired
	Queue queue;
	@Autowired
	JmsTemplate jmsTemplate;

	
	private static final Logger log = LoggerFactory.getLogger(PFServiceImpl.class);

	
	@Override
	public String pfDetails(PFRequestDto pfrequest) {
		XmlMapper mapper = new XmlMapper();
		String xml=null;
		try {
			xml = mapper.writeValueAsString(pfrequest);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("xml"+xml);
		jmsTemplate.convertAndSend(queue,xml);
		return "Success";
	}

}
