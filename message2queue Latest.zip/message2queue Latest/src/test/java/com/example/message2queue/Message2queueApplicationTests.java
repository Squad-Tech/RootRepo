package com.example.message2queue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Message2queueApplicationTests {

	@Test
	void contextLoads() {
	}

}
