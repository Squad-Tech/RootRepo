package com.example.message2queue.service;


import com.example.message2queue.dto.MessageDto;


public interface ProducerService {
	public String producerDetails(MessageDto producerrequest);

}
