package com.example.message2queue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Message2queueApplication {

	public static void main(String[] args) {
		SpringApplication.run(Message2queueApplication.class, args);
	}

}
