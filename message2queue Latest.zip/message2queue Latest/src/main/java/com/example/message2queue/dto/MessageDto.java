package com.example.message2queue.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

 

public class MessageDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long accountNumber;
    private BigDecimal transferAmount;
    private String bankName;
    private BigDecimal beneficiaryAccountNumber;
    private String BeneficiaryIfscCode;
    private Date date;
    private String formatType;

    public Long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

 
    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public BigDecimal getBeneficiaryAccountNumber() {
        return beneficiaryAccountNumber;
    }

    public void setBeneficiaryAccountNumber(BigDecimal beneficiaryAccountNumber) {
        this.beneficiaryAccountNumber = beneficiaryAccountNumber;
    }

    public String getBeneficiaryIfscCode() {
        return BeneficiaryIfscCode;
    }

    public void setBeneficiaryIfscCode(String beneficiaryIfscCode) {
        BeneficiaryIfscCode = beneficiaryIfscCode;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getFormatType() {
        return formatType;
    }

    public void setFormatType(String formatType) {
        this.formatType = formatType;
    }

}