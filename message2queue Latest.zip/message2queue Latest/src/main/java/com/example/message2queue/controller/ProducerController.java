package com.example.message2queue.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.message2queue.dto.MessageDto;
import com.example.message2queue.service.ProducerService;

@RestController
public class ProducerController {
	@Autowired
	ProducerService producerService;

	/*
	 * @PostMapping(value = "/producer", consumes = { "application/JSON",
	 * "application/XML" }, produces = { "application/JSON", "application/XML" })
	 */
	@PostMapping("/producer")
	public ResponseEntity<String> setPFDetails(@RequestBody MessageDto producerrequest) {
		String msg = null;
		try {
		msg = producerService.producerDetails(producerrequest);
		return new ResponseEntity<String>(msg,HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(msg,HttpStatus.BAD_REQUEST);
		}
	}

}
