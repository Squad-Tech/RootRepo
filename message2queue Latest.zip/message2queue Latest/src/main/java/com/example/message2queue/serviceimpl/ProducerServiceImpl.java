package com.example.message2queue.serviceimpl;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.example.message2queue.dto.MessageDto;
import com.example.message2queue.service.ProducerService;
@Service
public class ProducerServiceImpl implements ProducerService{
	@Autowired
	Queue queue;
	@Autowired
	JmsTemplate jmsTemplate;

	@Override
	public String producerDetails(MessageDto producerrequest) {
		// TODO Auto-generated method stub
		jmsTemplate.convertAndSend(queue,producerrequest);
		return "Success";
	}

}
